package com.lite.launcher

import android.annotation.TargetApi
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.drawable.AnimatedImageDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * Fondo: imagen (reducida a la pantalla), GIF/WebP animado (reducido) o vídeo en bucle sin sonido.
 * pause() libera todo lo pesado; resume() lo vuelve a crear.
 */
class WallpaperView(ctx: Context) : FrameLayout(ctx), TextureView.SurfaceTextureListener {
    private val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val tex = TextureView(ctx)
    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var uri: Uri? = null
    private var kind = "image"
    private var token = 0
    private var vw = 0
    private var vh = 0

    init {
        addView(img, LayoutParams(-1, -1))
        addView(tex, LayoutParams(-1, -1))
        tex.surfaceTextureListener = this
        tex.visibility = View.GONE
    }

    fun load(u: Uri?, k: String) {
        releaseAll()
        uri = u
        kind = k
        img.setImageDrawable(null)
        tex.visibility = View.GONE
        if (u == null) return
        val my = ++token
        when (k) {
            "video" -> {
                tex.visibility = View.VISIBLE
                if (tex.isAvailable) startVideo()
            }
            "anim" -> if (Build.VERSION.SDK_INT >= 28) loadAnim(u, my) else loadStatic(u, my)
            else -> loadStatic(u, my)
        }
    }

    fun pause() {
        releasePlayer()
        stopAnim()
    }

    fun resume() {
        if (kind == "video") { if (tex.isAvailable) startVideo() } else startAnim()
    }

    private fun releaseAll() {
        token++
        releasePlayer()
        stopAnim()
    }

    // ---------- imagen ----------
    private fun loadStatic(u: Uri, my: Int) {
        val dm = resources.displayMetrics
        Thread {
            val bmp = try { decode(u, dm.widthPixels, dm.heightPixels) } catch (e: Throwable) { null }
            post { if (my == token && bmp != null) img.setImageBitmap(bmp) }
        }.start()
    }

    private fun decode(u: Uri, w: Int, h: Int): Bitmap? {
        val big = maxOf(w, h)
        val small = minOf(w, h)
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (minOf(o.outWidth, o.outHeight) / (s * 2) >= small && maxOf(o.outWidth, o.outHeight) / (s * 2) >= big) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        return context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }

    // ---------- GIF / WebP animado ----------
    @TargetApi(28)
    private fun loadAnim(u: Uri, my: Int) {
        Thread {
            val dr = try {
                val src = ImageDecoder.createSource(context.contentResolver, u)
                ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                    val sz = info.size
                    val sc = minOf(1f, 960f / maxOf(sz.width, sz.height))
                    dec.setTargetSize(maxOf(1, (sz.width * sc).toInt()), maxOf(1, (sz.height * sc).toInt()))
                }
            } catch (e: Throwable) { null }
            post {
                if (my == token && dr != null) {
                    img.setImageDrawable(dr)
                    startAnim()
                }
            }
        }.start()
    }

    private fun startAnim() {
        val d = img.drawable
        if (Build.VERSION.SDK_INT >= 28 && d is AnimatedImageDrawable) {
            d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
            d.start()
        }
    }

    private fun stopAnim() {
        val d = img.drawable
        if (Build.VERSION.SDK_INT >= 28 && d is AnimatedImageDrawable) d.stop()
    }

    // ---------- vídeo ----------
    private fun startVideo() {
        val u = uri ?: return
        val st = tex.surfaceTexture ?: return
        releasePlayer()
        try {
            val mp = MediaPlayer()
            val sf = Surface(st)
            surface = sf
            mp.setSurface(sf)
            mp.setDataSource(context, u)
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            mp.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; applyCrop() }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            releasePlayer()
        }
    }

    private fun releasePlayer() {
        try { player?.release() } catch (_: Exception) {}
        player = null
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }

    private fun applyCrop() {
        val tw = tex.width.toFloat()
        val th = tex.height.toFloat()
        if (vw == 0 || vh == 0 || tw == 0f || th == 0f) return
        val s = maxOf(tw / vw, th / vh)
        val m = Matrix()
        m.setScale(vw * s / tw, vh * s / th, tw / 2f, th / 2f)
        tex.setTransform(m)
    }

    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        if (kind == "video") startVideo()
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) { applyCrop() }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        releasePlayer()
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
}
