package com.lite.launcher

import android.app.ActivityOptions
import android.content.Context
import android.graphics.Rect
import android.widget.Toast

object WindowLauncher {
    /** Abre la app en una ventana flotante (freeform) centrada. Si el sistema no lo permite, la abre normal. */
    fun open(ctx: Context, app: AppItem) {
        val p = Prefs(ctx)
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels * p.winW / 100
        val h = dm.heightPixels * p.winH / 100
        val l = (dm.widthPixels - w) / 2
        val t = (dm.heightPixels - h) / 2
        val intent = app.intent()
        try {
            val opts = ActivityOptions.makeBasic()
            opts.setLaunchBounds(Rect(l, t, l + w, t + h))
            try {
                // 5 = WINDOWING_MODE_FREEFORM. API oculta: si el sistema la bloquea, se ignora.
                ActivityOptions::class.java
                    .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                    .invoke(opts, 5)
            } catch (_: Throwable) {
            }
            ctx.startActivity(intent, opts.toBundle())
        } catch (e: Exception) {
            try {
                ctx.startActivity(intent)
                Toast.makeText(ctx, "Este sistema no permitió abrirla en ventana", Toast.LENGTH_SHORT).show()
            } catch (e2: Exception) {
                Toast.makeText(ctx, "No se pudo abrir la app", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
