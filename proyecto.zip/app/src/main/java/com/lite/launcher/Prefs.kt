package com.lite.launcher

import android.content.Context
import android.content.SharedPreferences
import kotlin.reflect.KProperty

private class IntPref(private val sp: SharedPreferences, private val key: String, private val def: Int) {
    operator fun getValue(t: Any?, p: KProperty<*>): Int = sp.getInt(key, def)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Int) { sp.edit().putInt(key, v).apply() }
}

private class BoolPref(private val sp: SharedPreferences, private val key: String, private val def: Boolean) {
    operator fun getValue(t: Any?, p: KProperty<*>): Boolean = sp.getBoolean(key, def)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Boolean) { sp.edit().putBoolean(key, v).apply() }
}

/** Todos los ajustes del launcher. Para añadir uno nuevo: una línea aquí. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("lite", Context.MODE_PRIVATE)

    var wallUri: String?
        get() = sp.getString("wall_uri", null)
        set(v) { sp.edit().putString("wall_uri", v).apply() }

    var wallKind: String
        get() = sp.getString("wall_kind", "image") ?: "image"
        set(v) { sp.edit().putString("wall_kind", v).apply() }

    var columns: Int by IntPref(sp, "columns", 6)
    var iconDp: Int by IntPref(sp, "icon_dp", 56)
    var dim: Int by IntPref(sp, "dim", 25)
    var winW: Int by IntPref(sp, "win_w", 60)
    var winH: Int by IntPref(sp, "win_h", 70)
    var labels: Boolean by BoolPref(sp, "labels", true)
    var clock: Boolean by BoolPref(sp, "clock", true)
    var search: Boolean by BoolPref(sp, "search", true)
}
