package com.lite.launcher

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** list=false: celda de cuadrícula (icono + nombre). list=true: fila de lista. */
class AppAdapter(private val ctx: Context, private val prefs: Prefs, private val list: Boolean) : BaseAdapter() {
    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private var query = ""

    fun submit(a: List<AppItem>) { all = a; applyFilter() }
    fun filter(q: String) { query = q.trim().lowercase(); applyFilter() }

    private fun applyFilter() {
        shown = if (query.isEmpty()) all else all.filter { it.label.lowercase().contains(query) }
        notifyDataSetChanged()
    }

    override fun getCount() = shown.size
    override fun getItem(position: Int): AppItem = shown[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val d = ctx.resources.displayMetrics.density
        val pad = (8 * d).toInt()
        val iconPx = ((if (list) 40 else prefs.iconDp) * d).toInt()
        val row: LinearLayout
        val icon: ImageView
        val label: TextView
        if (convertView == null) {
            row = LinearLayout(ctx).apply {
                orientation = if (list) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
                gravity = if (list) Gravity.CENTER_VERTICAL else Gravity.CENTER_HORIZONTAL
                setPadding(pad, pad, pad, pad)
            }
            icon = ImageView(ctx)
            row.addView(icon, LinearLayout.LayoutParams(iconPx, iconPx))
            label = TextView(ctx).apply {
                setTextColor(Color.WHITE)
                textSize = if (list) 16f else 12f
                maxLines = if (list) 1 else 2
                ellipsize = TextUtils.TruncateAt.END
                gravity = if (list) Gravity.START else Gravity.CENTER_HORIZONTAL
                if (!list) setShadowLayer(4f, 0f, 1f, Color.BLACK)
            }
            val lp = LinearLayout.LayoutParams(
                if (list) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            if (list) lp.leftMargin = pad * 2 else lp.topMargin = pad / 2
            row.addView(label, lp)
        } else {
            row = convertView as LinearLayout
            icon = row.getChildAt(0) as ImageView
            label = row.getChildAt(1) as TextView
        }
        val a = shown[position]
        val key = a.pkg + "/" + a.cls
        row.tag = key
        label.text = a.label
        label.visibility = if (list || prefs.labels) View.VISIBLE else View.GONE
        icon.setImageBitmap(null)
        Icons.get(ctx, a, iconPx) { bmp -> if (row.tag == key) icon.setImageBitmap(bmp) }
        return row
    }
}
