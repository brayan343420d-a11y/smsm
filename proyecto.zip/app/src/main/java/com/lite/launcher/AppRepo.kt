package com.lite.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.Executors

data class AppItem(val label: String, val pkg: String, val cls: String) {
    fun intent(): Intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(pkg, cls)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
}

object AppRepo {
    @Volatile var apps: List<AppItem> = emptyList()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun refresh(ctx: Context, done: (List<AppItem>) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            val pm = app.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo != null && it.activityInfo.packageName != app.packageName }
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
                .sortedBy { it.label.lowercase() }
            apps = list
            main.post { done(list) }
        }
    }
}

/** Iconos como bitmaps pequeños con caché de 8 MB como máximo (así la RAM no se dispara). */
object Icons {
    private val cache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val io = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun get(ctx: Context, a: AppItem, px: Int, cb: (Bitmap) -> Unit) {
        val key = a.pkg + "/" + a.cls + "@" + px
        val hit = cache.get(key)
        if (hit != null) { cb(hit); return }
        val app = ctx.applicationContext
        io.execute {
            try {
                val d = app.packageManager.getActivityIcon(ComponentName(a.pkg, a.cls))
                val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
                d.setBounds(0, 0, px, px)
                d.draw(Canvas(bmp))
                cache.put(key, bmp)
                main.post { cb(bmp) }
            } catch (_: Exception) {
            }
        }
    }
}
