package com.lite.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity(), Host {
    private lateinit var prefs: Prefs
    private lateinit var wall: WallpaperView
    private lateinit var dim: View
    private lateinit var grid: GridView
    private lateinit var header: LinearLayout
    private var adapter: AppAdapter? = null
    private var query = ""
    private var lastWall = "#"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }

        wall = WallpaperView(this)
        dim = View(this)
        header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(12), dp(8))
        }
        grid = GridView(this).apply {
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(6)
            setPadding(dp(12), 0, dp(12), 0)
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setSelector(ColorDrawable(0x22FFFFFF))
            setOnItemClickListener { _, _, pos, _ ->
                adapter?.getItem(pos)?.let { launch(it) }
            }
            setOnItemLongClickListener { _, _, pos, _ ->
                adapter?.getItem(pos)?.let { showMenu(it) }
                true
            }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(header, LinearLayout.LayoutParams(-1, -2))
            addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        val root = FrameLayout(this).apply {
            addView(wall, FrameLayout.LayoutParams(-1, -1))
            addView(dim, FrameLayout.LayoutParams(-1, -1))
            addView(content, FrameLayout.LayoutParams(-1, -1))
            setOnApplyWindowInsetsListener { _, ins ->
                content.setPadding(
                    ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                    ins.systemWindowInsetRight, ins.systemWindowInsetBottom
                )
                ins
            }
        }
        setContentView(root)
        root.requestApplyInsets()
    }

    override fun onStart() {
        super.onStart()
        grid.numColumns = prefs.columns
        val a = AppAdapter(this, prefs, false)
        a.submit(AppRepo.apps)
        a.filter(query)
        adapter = a
        grid.adapter = a
        dim.setBackgroundColor(Color.argb(prefs.dim * 255 / 100, 0, 0, 0))
        buildHeader()

        val key = (prefs.wallUri ?: "") + "|" + prefs.wallKind
        if (key != lastWall) {
            lastWall = key
            wall.load(prefs.wallUri?.let { Uri.parse(it) }, prefs.wallKind)
        } else {
            wall.resume()
        }
        AppRepo.refresh(this) { adapter?.submit(it) }
    }

    override fun onStop() {
        super.onStop()
        wall.pause() // libera vídeo/animación para ahorrar RAM mientras usas otra app
    }

    override fun onBackPressed() {
        // En un launcher, "atrás" no hace nada.
    }

    private fun buildHeader() {
        header.removeAllViews()
        query = ""
        Modules.all.filter { it.isEnabled(prefs) }.forEach { header.addView(it.createView(this, this)) }
        val menu = TextView(this).apply {
            text = "⋮"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(4), dp(16), dp(4))
            setOnClickListener { openSettings() }
        }
        val spacer = View(this)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f).also { if (prefs.search) it.weight = 0f })
        header.addView(menu, LinearLayout.LayoutParams(-2, -2))
    }

    override fun filter(q: String) {
        query = q
        adapter?.filter(q)
    }

    override fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun launch(a: AppItem) {
        try {
            startActivity(a.intent())
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir ${a.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(a: AppItem) {
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(arrayOf("Abrir", "Abrir en ventana", "Información de la app", "Desinstalar")) { _, which ->
                try {
                    when (which) {
                        0 -> launch(a)
                        1 -> WindowLauncher.open(this, a)
                        2 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                        3 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "No se pudo completar la acción", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }
}
