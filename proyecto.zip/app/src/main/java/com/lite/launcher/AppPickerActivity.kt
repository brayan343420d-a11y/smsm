package com.lite.launcher

import android.app.Activity
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView

/** Ventanita con buscador y lista de apps. Al tocar una, se abre en ventana. */
class AppPickerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val adapter = AppAdapter(this, Prefs(this), true)

        val search = EditText(this).apply {
            hint = "Buscar app…"
            isSingleLine = true
            addTextChangedListener(SimpleWatcher { adapter.filter(it) })
        }
        val listView = ListView(this).apply {
            this.adapter = adapter
            setOnItemClickListener { _, _, pos, _ ->
                WindowLauncher.open(this@AppPickerActivity, adapter.getItem(pos))
                finish()
            }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (12 * d).toInt()
            setPadding(p, p, p, p)
            addView(search, LinearLayout.LayoutParams(-1, -2))
            addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)

        val dm = resources.displayMetrics
        val w = minOf((dm.widthPixels * 0.9f).toInt(), (480 * d).toInt())
        window.setLayout(w, (dm.heightPixels * 0.8f).toInt())

        if (AppRepo.apps.isNotEmpty()) adapter.submit(AppRepo.apps)
        AppRepo.refresh(this) { adapter.submit(it) }
    }
}
