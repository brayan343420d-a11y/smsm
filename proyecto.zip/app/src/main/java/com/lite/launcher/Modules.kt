package com.lite.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextClock

/** Lo que el launcher le ofrece a un módulo. */
interface Host {
    fun filter(q: String)
    fun openSettings()
}

/**
 * Un módulo es una pieza de la parte de arriba del launcher (reloj, buscador...).
 * PARA AÑADIR UNO NUEVO: crea un `object MiModulo : LauncherModule` y agrégalo a la lista de abajo.
 */
interface LauncherModule {
    val id: String
    fun isEnabled(p: Prefs): Boolean
    fun createView(ctx: Context, host: Host): View
}

class SimpleWatcher(private val f: (String) -> Unit) : TextWatcher {
    override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
}

object ClockModule : LauncherModule {
    override val id = "clock"
    override fun isEnabled(p: Prefs) = p.clock
    override fun createView(ctx: Context, host: Host): View {
        val d = ctx.resources.displayMetrics.density
        return TextClock(ctx).apply {
            format24Hour = "HH:mm"
            format12Hour = "h:mm"
            textSize = 34f
            setTextColor(Color.WHITE)
            setShadowLayer(4f, 0f, 1f, Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = (16 * d).toInt() }
        }
    }
}

object SearchModule : LauncherModule {
    override val id = "search"
    override fun isEnabled(p: Prefs) = p.search
    override fun createView(ctx: Context, host: Host): View {
        val d = ctx.resources.displayMetrics.density
        return EditText(ctx).apply {
            hint = "Buscar apps"
            isSingleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(0x99FFFFFF.toInt())
            val p = (14 * d).toInt()
            setPadding(p, (8 * d).toInt(), p, (8 * d).toInt())
            background = GradientDrawable().apply {
                setColor(0x55000000)
                cornerRadius = 24 * d
            }
            addTextChangedListener(SimpleWatcher { host.filter(it) })
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
    }
}

object Modules {
    val all: List<LauncherModule> = listOf(ClockModule, SearchModule)
}
