package com.lite.launcher

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class SettingsActivity : Activity() {
    private lateinit var p: Prefs

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(48))
        }
        col.addView(TextView(this).apply {
            text = "Ajustes del launcher"
            textSize = 24f
        })

        col.addView(section("Fondo"))
        col.addView(btn("Elegir fondo (imagen, GIF, WebP o vídeo)") { pick() })
        col.addView(btn("Quitar fondo") {
            p.wallUri = null
            toast("Fondo quitado")
        })
        col.addView(slider("Oscurecer fondo", 0, 80, p.dim, "%") { p.dim = it })

        col.addView(section("Cuadrícula"))
        col.addView(slider("Columnas", 3, 10, p.columns, "") { p.columns = it })
        col.addView(slider("Tamaño de iconos", 36, 96, p.iconDp, " dp") { p.iconDp = it })
        col.addView(switchRow("Mostrar nombres de las apps", p.labels) { p.labels = it })

        col.addView(section("Parte de arriba"))
        col.addView(switchRow("Reloj", p.clock) { p.clock = it })
        col.addView(switchRow("Buscador", p.search) { p.search = it })

        col.addView(section("Apps en ventana"))
        col.addView(slider("Ancho de la ventana", 30, 95, p.winW, "%") { p.winW = it })
        col.addView(slider("Alto de la ventana", 30, 95, p.winH, "%") { p.winH = it })
        col.addView(btn("Activar ventanas libres (ajustes de desarrollador)") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                toast("Activa primero las opciones de desarrollador")
            }
        })
        col.addView(TextView(this).apply {
            text = "Ahí activa \"Habilitar ventanas de forma libre\" y \"Forzar que las actividades sean redimensionables\", y reinicia la tablet. Después añade el mosaico \"Apps en ventana\" en el panel de ajustes rápidos (lápiz)."
            textSize = 13f
            setPadding(0, dp(8), 0, 0)
        })

        col.addView(section("Sistema"))
        col.addView(btn("Definir como launcher predeterminado") {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) {
                toast("No se pudo abrir los ajustes")
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun section(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(0xFF7FB2FF.toInt())
        setPadding(0, dp(28), 0, dp(4))
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun switchRow(label: String, value: Boolean, save: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        isChecked = value
        setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, c -> save(c) }
    }

    private fun slider(title: String, lo: Int, hi: Int, value: Int, unit: String, save: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        val tv = TextView(this).apply { textSize = 15f; text = "$title: $value$unit" }
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + lo
                tv.text = "$title: $v$unit"
                save(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        val t = contentResolver.getType(u) ?: ""
        p.wallKind = when {
            t.startsWith("video") -> "video"
            t == "image/gif" || t == "image/webp" -> "anim"
            else -> "image"
        }
        p.wallUri = u.toString()
        toast("Fondo aplicado")
    }
}
